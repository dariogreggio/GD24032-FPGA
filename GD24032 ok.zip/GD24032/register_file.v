// da grok 12/7/26

module register_file #(
    parameter WIDTH = 32
)(
    input  wire             clk,
    input  wire             we,          // write enable
    input  wire [4:0]       wa,          // write address
    input  wire [WIDTH-1:0] wd,          // write data
    
    input  wire [4:0]       ra1,         // read address 1
    output wire [WIDTH-1:0] rd1,
    
    input  wire [4:0]       ra2,         // read address 2
    output wire [WIDTH-1:0] rd2
);

reg [WIDTH-1:0] regs [0:31];

// ====================== Scrittura ======================
always @(posedge clk) begin
    if (we)
        regs[wa] <= wd;
end

// ====================== Letture ======================
assign rd1 = regs[ra1];
assign rd2 = regs[ra2];

endmodule
